module.exports = {
    'secret': 'nodeauthsecret',
    'database': 'mongodb://localhost:27017/EngineersManagement'
};