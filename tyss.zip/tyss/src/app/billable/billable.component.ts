import { Component, OnInit } from '@angular/core';
import { BillableEmpService } from '../billable-emp.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-billable',
  templateUrl: './billable.component.html',
  styleUrls: ['./billable.component.css']
})
export class BillableComponent implements OnInit {
 
  constructor(private billableService :BillableEmpService , private router : Router) { }

  billableEmpData:any= [] ;

  ngOnInit() {
  }

  printBillableForm(billableEmp){
    this.billableService.postData(billableEmp).subscribe(billable=>{
      console.log(billable);
      this.billableEmpData = billable;
      this.router.navigate(['./billableEmpData']);

    },(err)=>{
      console.log(err);
    },()=>{
      console.log("data sent successfully");
    })
  }


}
