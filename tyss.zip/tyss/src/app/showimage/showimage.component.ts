import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showimage',
  templateUrl: './showimage.component.html',
  styleUrls: ['./showimage.component.css']
})
export class ShowimageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
