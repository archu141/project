import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  backendurl='http://localhost:4000';

  constructor(private http:HttpClient) { }

  data:any;

  postData(client, imagename): Observable<any> {
    const obj = {
      client,
      imagename
    };
    return this.http.post(`${this.backendurl}/addClient`, obj);
  }


  // postData(client){
  //   return this.http.post(`${this.backendurl}/addClient`,client);
  
  // }

  getClientData(){
    return this.http.get(`${this.backendurl}/getClient`);
  }
  updateClientDetails(data){
    return this.http.post(`${this.backendurl}/updateClientDetails`,data)
  }
  deleteClient(id){
    return this.http.delete(`${this.backendurl}/deleteClients/${id}`)
  }
}
