import { Component, OnInit } from '@angular/core';
import { BillableEmpService } from '../billable-emp.service';

@Component({
  selector: 'app-package-details',
  templateUrl: './package-details.component.html',
  styleUrls: ['./package-details.component.css']
})
export class PackageDetailsComponent implements OnInit {
  items:any = [];

  packageDetails = {
    _id: null,
    dateOfPaymentByTyss: null,
    dateOfPaymentByClient: null,
    paymentByTyss: null,
    paymentByClient: null,
   
  }

  constructor( private service2 : BillableEmpService) {
    this.getClientDetails();

   }

  private packageDetail : any = [];

  getClientDetails() {
    this.service2.getPackageData().subscribe(details =>{
      this.items = details;
      console.log(this.packageDetail);
    }, err =>{
      console.log(err);
    }, () =>{
      console.log("packageDetail got successfully");
    })
 }

  printSelectedRow(data){
    console.log(data);
    this.packageDetails=data
  }

  onChangePage(packageDetail :Array<any>){
    this.packageDetail = packageDetail;
  }

  ngOnInit() {
    this.items = Array(168).fill(0).map((x,i) =>({id:(i+1), name:`${i+1}`}));

  }

}
