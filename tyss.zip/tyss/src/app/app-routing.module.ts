import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientFormComponent } from './client-form/client-form.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ClientDetailsComponent } from './client-details/client-details.component';
import { BillableComponent } from './billable/billable.component';
import { PackageBillableComponent } from './package-billable/package-billable.component';
import { PackageDetailsComponent } from './package-details/package-details.component';
import { BillableEmpComponent } from './billable-emp/billable-emp.component';
import { ShowimageComponent } from './showimage/showimage.component';


const routes: Routes = [
  { path: 'client' , component: ClientFormComponent},
  { path: 'dashboard' , component: DashboardComponent},
  { path: 'client-details' , component: ClientDetailsComponent},
  { path: 'billableemp' , component: BillableComponent},
  { path: 'packageBillable' , component: PackageBillableComponent},
  { path: 'packageDetails' , component: PackageDetailsComponent},
  { path: 'billableEmpData' , component: BillableEmpComponent},
  { path: 'showimages' , component: ShowimageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
