import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-client-details',
  templateUrl: './client-details.component.html',
  styleUrls: ['./client-details.component.css']
})
export class ClientDetailsComponent implements OnInit {
  private clientsDetail : any = [];

  items:any = [];


  clientDetails = {
    _id: null,
    clientName: null,
    clientShortName: null,
    department: null,
    clientEmail: null,
    clientNo: null,
    companyWebsite: null,
    streetaddress: null,
    city: null,
    state:null ,
    zip:null ,
    country: null
  }

  constructor(private clientService : ClientService , private http: HttpClient, private router: Router) { 
    this.getClientDetails();
  }


 getClientDetails() {
    this.clientService.getClientData().subscribe(clients =>{
      this.items = clients;
      console.log(this.clientsDetail);
    }, err =>{
      console.log(err);
    }, () =>{
      console.log("clients Details got successfully");
    })
 }

 printSelectedRow(data){
   console.log(data);
   this.clientDetails=data
 }
 updateClients(form: NgForm){
  console.log(form.value)
this.clientService.updateClientDetails(form.value).subscribe(updatedClients=>{
  console.log(updatedClients);
   this.getClientDetails();

},err=>{
  console.log(err);
},()=>{
  console.log("Updated clients successfully");
})
}

deleteClientDetails(id){
  console.log(id);
  this.clientService.deleteClient(id).subscribe(data=>{
    this.getClientDetails();
    console.log(data);
  },err=>{
    console.log(err);
  },()=>{
    console.log("client deleted success");
  });
 
}

  ngOnInit() {
    this.items = Array(168).fill(0).map((x,i) =>({id:(i+1), name:`${i+1}`}));
  }
 
  onChangePage(clientsDetail :Array<any>){
    this.clientsDetail = clientsDetail;
  }
}




