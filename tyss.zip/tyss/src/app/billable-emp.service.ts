import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'


@Injectable({
  providedIn: 'root'
})
export class BillableEmpService {

  constructor(private http: HttpClient) { }

  backendurl='http://localhost:4000';


  postData(billableEmp){
    return this.http.post(`${this.backendurl}/addBillabeEngineerData`,billableEmp);
  
  }

  getBillableData(){
    return this.http.get(`${this.backendurl}/getBillabeEngineerData`);
  }
  postPackageData(billableEmpl){
    return this.http.post(`${this.backendurl}/addBillablePackageData`,billableEmpl);
  
  }

  getPackageData(){
    return this.http.get(`${this.backendurl}/getBillablePackageData`);
  }

}
