import { Component, OnInit } from '@angular/core';
import { BillableEmpService } from '../billable-emp.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-package-billable',
  templateUrl: './package-billable.component.html',
  styleUrls: ['./package-billable.component.css']
})
export class PackageBillableComponent implements OnInit {
  emp: any=[];

  constructor( private service : BillableEmpService , private  router : Router ) { }

  printPackageForm(packageData){
    this.service. postPackageData(packageData).subscribe(packageData=>{
      console.log(packageData);
      this.emp=packageData;
      this.router.navigate(['./packageDetails']);

    },(err)=>{
      console.log(err);
    },()=>{
      console.log("data sent successfully");
    })
  }

  ngOnInit() {
  }

}
