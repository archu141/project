import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SlickCarouselModule } from 'ngx-slick-carousel';

import { JwPaginationComponent } from 'jw-angular-pagination';
import { HighchartsChartModule } from 'highcharts-angular';
import { FusionChartsModule } from "angular-fusioncharts";
import * as FusionCharts from "fusioncharts";
import * as Widgets from "fusioncharts/fusioncharts.widgets";

import * as FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";

FusionChartsModule.fcRoot(FusionCharts, Widgets, FusionTheme);


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ClientFormComponent } from './client-form/client-form.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ClientDetailsComponent } from './client-details/client-details.component';
import { BillableComponent } from './billable/billable.component';
import { PackageBillableComponent } from './package-billable/package-billable.component';
import { PackageDetailsComponent } from './package-details/package-details.component';
import { BillableEmpComponent } from './billable-emp/billable-emp.component';
import { NgxUploaderModule } from 'ngx-uploader';
import { ShowimageComponent } from './showimage/showimage.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    ClientFormComponent,
    DashboardComponent,
    ClientDetailsComponent,
    JwPaginationComponent,
    BillableComponent,
    PackageBillableComponent,
    PackageDetailsComponent,
    BillableEmpComponent,
    ShowimageComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    FusionChartsModule,
    HighchartsChartModule,
    NgxUploaderModule,
    SlickCarouselModule,
    



  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
