import { Component, OnInit } from '@angular/core';
import { BillableEmpService } from '../billable-emp.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-billable-emp',
  templateUrl: './billable-emp.component.html',
  styleUrls: ['./billable-emp.component.css']
})
export class BillableEmpComponent implements OnInit {
  items:any = [];


  constructor(private billableService : BillableEmpService, private router : Router) { 
    this.getBillableDetails();
  }

  private  billableData:any = [];


  getBillableDetails() {
    this.billableService.getBillableData().subscribe(emp =>{
      this.items = emp;
      console.log(this.billableData);
    }, err =>{
      console.log(err);
    }, () =>{
      console.log("clients Details got successfully");
    })
 }

  ngOnInit() {
    this.items = Array(168).fill(0).map((x,i) =>({id:(i+1), name:`${i+1}`}));

  }

  onChangePage(billableData :Array<any>){
    this.billableData = billableData;

  }
}
